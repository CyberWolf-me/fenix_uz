# Fenix Restobar — Website Build Brief

Prototype phase · Version 0.1 · 13 November 2026 · Living document

## 1. How to use this document

This brief is for the people and AI agents building the Fenix website. It says what we are building, what "done" means, what we still need, and the order of work. Every fact carries a label:

- **Verified**: seen on a public source (Fenix's Telegram channel or a cited article).
- **Draft**: taken from the design concept's data file, which was copied from a map listing. Not confirmed by the owner.
- **Assumption**: our working decision, open to change.
- **Owner to confirm**: the restaurant must answer this before launch.

Rule for agents: never invent facts. If something is missing, insert a visible placeholder (see section 12) and list it in your report.

## 2. Project summary

Fenix is a restaurant and bar in Tashkent serving European and Korean dishes, with cocktails, house lemonades and live music. The owner has no fixed idea of what the site should look like, so we are first building a prototype to react to. The prototype uses AI-generated images as stand-ins. They are not photos of the real rooms or dishes and must be replaced before launch.

### Restaurant facts

- **Name**: "FENIX Restobar" on Telegram; the concept uses "Fenix, Restaurant & Bar". Owner to confirm the official name.
- **Address (Verified)**: Tashkent, Yashnobod district, Husnobod 5-tor ko'chasi, 1.
- **Phones (Verified, Telegram)**: +998 97 185 00 10 and +998 97 185 00 20. The concept shows only the second.
- **Hours (Draft)**: Mon–Thu 12:00–00:00, Fri–Sat 12:00–02:00, Sun 12:00–00:00. Live music Fri and Sat from 20:00. Owner to confirm.
- **Capacity (conflict)**: Telegram says a first-floor hall for 120 guests and a second-floor hall for 170. The concept says 100 seats. Use the Telegram numbers until the owner confirms.
- **Average bill (Draft)**: 200 000–500 000 so'm.
- **Social**: Instagram @fenix.tashkent; Telegram t.me/fenix\_tashkent (38 subscribers when we checked).
- **Events hosted (Verified)**: weddings, anniversaries, birthdays, corporate events, family celebrations, and holiday evenings such as Navruz.
- **Language of public posts**: Russian.

## 3. Goals

User jobs in priority order (Assumption; owner to confirm the order of the first two):

1. Reserve a table from a phone in under a minute.
2. Ask about an event or banquet.
3. Read the menu with prices.
4. Check hours, find the place, call.
5. Order for pickup or delivery (Phase 2).

Business goals: more direct bookings and event inquiries, fewer calls just to ask about the menu or prices, and a credible presence beyond Instagram and Telegram.

Non-goals for Phase 1: live table management, loyalty programs, gift cards, user accounts, a blog.

Success measures after launch: reservation requests per week, event inquiries per month, call taps, directions taps, menu views. There is no website today, so the baseline is zero. Set targets with the owner after the first month of data.

## 4. Scope by phase

- **Phase 0, prototype (now)**: clickable prototype with the real menu, placeholder images, working layouts at phone and desktop widths, form flows that validate but need no backend.
- **Phase 1, launch**: Home, Menu, Events, Gallery, Contact; Russian, Uzbek and English; reservation request and event inquiry that reach staff; real photography; SEO; analytics; privacy page.
- **Phase 2, ordering**: pickup and delivery from our own site, with online payment. Only after Phase 1 is live and the owner has decided how it fits with delivery apps (section 7.8).
- **Later**: admin panel for menu edits, table inventory, promotions.

## 5. Site map

- **Home**: hero, short idea statement, key facts, signature dishes, the rooms, music nights, Reserve block.
- **Menu**: all categories, sticky category navigation.
- **Events**: banquet halls, event types, inquiry form.
- **Gallery**: rooms, dishes, events. Real photos only at launch.
- **Contact**: hours, address, map links, phones, reservation form.
- **Legal**: privacy policy.

The concept's nav (Home, Menu, About, Gallery, Contact) changes in two ways: add Events, and keep a persistent Reserve button in the header. About can be a section on Home.

URLs: `/ru/`, `/uz/`, `/en/` prefixes. Default language Russian (Assumption).

## 6. Design system

Base: Direction A ("Ember") from the concept files, with accessibility fixes. **The palette is provisional until real photos exist**, because the dark, lattice-screened look came from generated images.

### Tokens

```css
:root {
  /* color */
  --bg: #0B0906;
  --bg-raised: #14110A;
  --ink: #F0E7D6;                         /* main text, 16:1 on bg */
  --text-dim: rgba(240, 231, 214, .56);   /* body text, about 5.4:1 */
  --accent: #C08A3E;                      /* buttons, prices, links, 6.6:1 */
  --on-accent: #0B0906;                   /* text on accent fill */
  --ember: #7E3A18;                       /* decoration only */
  --line: rgba(240, 231, 214, .15);       /* decoration only, never text */
  /* type */
  --font-display: 'Cormorant', Georgia, serif;
  --font-body: 'Jost', system-ui, sans-serif;
  /* spacing: 8px scale */
  --s1: 4px; --s2: 8px; --s3: 16px; --s4: 24px; --s5: 40px; --s6: 64px;
}
```

### Rules

- The concept's "faint" text tier measures about 2.3:1 and fails. Use it for lines and frames only, never for words.
- Body text 16px minimum. Labels 12px minimum, letter-spacing about 0.08em (the concept used up to 0.24em at 9–10px).
- Cormorant weight 300 only for large headings. The concept's font files cover Cyrillic for Cormorant 300 and 400 italic only, and for Jost 300, 400, 500. Add a heavier Cyrillic Cormorant weight for small headings, or use Jost for them.
- Uzbek letters oʻ and gʻ are covered by the Latin subsets. Korean characters have no font in the files, so use them only as artwork or add a subsetted Korean font.
- Tap targets at least 44px. Visible focus ring on every interactive element. No zoom lock. Respect `prefers-reduced-motion`. No autoplay video.
- Grid: 4 columns on phones, 12 on desktop, maximum content width about 1200px.
- Every dark-on-photo text block needs a scrim that keeps 4.5:1.

### Components

1. Header: logo, nav, language switcher (RU / UZ / EN), tap-to-call, sticky Reserve button.
2. Hero in two versions: photo, and type-only fallback.
3. Menu: sticky category chips on phones, item row with name, description, price in so'm, optional tags and photo.
4. Reservation form and event inquiry form, each with default, focus, error, loading and success states.
5. Hours block with an "open now" status.
6. Location block with Yandex Maps and Google Maps links.
7. Gallery with keyboard-accessible lightbox.
8. Footer with address, phones, hours, socials, privacy link.
9. Phase 2 set: cart, checkout, order status.

A live style-guide page showing every token and component state is a deliverable (task T1).

## 7. Functional requirements

### 7.1 Reservation request

- **Fields**: date, time, number of guests, name, phone, optional comment (allergies, occasion), privacy consent.
- **Date**: today to 60 days ahead (Assumption).
- **Time**: 30-minute slots inside opening hours; last slot an hour before closing (Owner to confirm). Fri/Sat hours run past midnight, so handle "closes 02:00 next day" correctly.
- **Guests**: 1–12 in the form. Larger groups are sent to the Events form.
- **Phone**: +998 mask, 9 digits after the country code, correct `autocomplete` attributes.
- **Result**: a request, not a confirmed table. The success message must say staff will confirm by phone or Telegram, with the time window the owner commits to (Owner to confirm).
- **Delivery to staff**: stored on the server and sent to a staff Telegram chat or email (Owner to choose).
- **Spam control**: honeypot field and rate limiting. Add a CAPTCHA only if abuse appears.
- **Failure**: if sending fails, show the phone numbers and keep the form data.

### 7.2 Event inquiry

Fields: event type (wedding, anniversary, birthday, corporate, other), approximate guests, approximate date, preferred hall (first floor, second floor, no preference), name, phone, comment, privacy consent. Same delivery, spam and failure rules as 7.1.

### 7.3 Menu

- The menu is HTML text, never a PDF. A PDF may exist as a secondary print link.
- Structured data per dish: id, category, name (ru, uz, en), description (ru, uz, en), price in so'm (number), tags, optional photo, available flag.
- Categories come from the owner's menus. The concept's four categories are placeholders and miss drinks entirely, although Telegram highlights cocktails, lemonades, a bar menu and beer.
- Prices shown as "285 000 so'm" (thin space for thousands).
- Allergen or spice tags only if the owner supplies them.
- No empty photo boxes. A dish without a photo simply has no photo.
- Category anchors are deep-linkable.

### 7.4 Languages

- Russian, Uzbek (Latin script) and English. Visible switcher in the header, choice remembered, `<html lang>` set per page, `hreflang` links.
- All visible text lives in language files, never in templates.
- If a translation is missing, fall back to Russian and log it.
- Drafts by AI are fine for the prototype. Native-speaker review is required for Russian and Uzbek before launch.

### 7.5 Hours, contact, maps

- Phones are tap-to-call links. The address links to maps.
- "Open now" is computed in the Asia/Tashkent time zone (UTC+5, no daylight saving).
- Map links: Yandex Maps and Google Maps. Use the Yandex Maps organization link once the owner provides it.

### 7.6 SEO

- `Restaurant` structured data (JSON-LD): name, address, phones, opening hours, cuisines (European, Korean), price range, menu URL, social links.
- Name, address and phone must match the Yandex Maps and Google listings exactly.
- Sitemap, Open Graph images, meta descriptions per language.
- Register with Yandex Webmaster and Google Search Console.
- Note that a larger Fenix restaurant group exists elsewhere (a Greek restaurant of the same name in the UK), so page titles must include "Tashkent".

### 7.7 Analytics and privacy

- Track: menu views, Reserve clicks, call taps, directions taps, form starts and completions, language choice.
- Analytics tool: Owner to choose. Yandex Metrica and Google Analytics are the usual options in the region. Avoid tools that need a cookie banner unless the owner wants them.
- Personal data (names, phones) collected by forms needs a privacy policy and a consent checkbox.
- **Check before launch**: reports say Uzbek law requires personal data of Uzbek citizens to be stored on servers inside Uzbekistan. We have not verified this. Confirm with a local lawyer, because it decides where the form backend and database are hosted.

### 7.8 Phase 2 ordering (not built in Phase 1)

Context from research:

- Delivery runs mainly through Yandex Eats (which absorbed part of Express24) and Uzum Tezkor; both were formally named dominant platforms. Wolt stopped operating in Uzbekistan on 5 March 2026.
- Many top Tashkent restaurants take bookings through Yandex, which requires a Yandex ID.
- Common payment methods: Payme, Click, Uzum, plus Uzcard and Humo cards; Click has announced Apple Pay support. Cash on delivery builds trust.

Decisions the owner must make first: what commission they pay the apps, whether they have their own couriers, delivery zones and minimum order, and which payment provider to contract. Until then, Phase 1 may link to the Fenix listing on Yandex Eats or Uzum Tezkor if one exists.

## 8. Non-functional requirements

### Performance

Targets are Google's Core Web Vitals "good" thresholds, measured on a mid-range Android phone with throttled 4G:

- Largest Contentful Paint 2.5 s or less
- Interaction to Next Paint 200 ms or less
- Cumulative Layout Shift 0.1 or less

Budgets (Assumption, to tune): hero image about 200 KB or less; JavaScript on the home page 100 KB gzipped or less; fonts 100 KB or less in total; images served as WebP or AVIF with set width and height; below-the-fold images lazy-loaded; first load of the home page about 1 MB or less excluding lazy images. The concept's 3 MB JPG originals must never be served.

### Accessibility

WCAG 2.2 level AA, tested by hand as well as by tools:

- Contrast 4.5:1 for text, 3:1 for large text and interface parts.
- Everything works with a keyboard alone; focus is always visible.
- Real `<label>` on every field; errors described in text, not color alone.
- Text resizes to 200% without losing content; pinch zoom stays on.
- Alt text in each language for every meaningful image.
- Skip link, correct heading order, landmarks.
- Spot checks with TalkBack (Android) and VoiceOver (iOS).

### Browsers and devices

Current Chrome, Safari (iOS 15 or later), Samsung Internet and Yandex Browser; Firefox and Edge on desktop. Design at 390 px wide first, then 768 px and 1440 px.

### Security and reliability

HTTPS only, security headers, server-side validation of every form, no secrets in client code, forms never lose a submission silently.

## 9. Recommended technical approach

This is a recommendation. Agents may propose alternatives if they meet section 8.

- A static-first site (for example Astro with TypeScript), because the pages are mostly content and speed matters most.
- Plain CSS with the custom properties from section 6. No heavy UI framework.
- Content in structured files: menu data, language files, restaurant facts in one place.
- Build-time image optimization with responsive sizes; self-hosted fonts subsetted for Latin and Cyrillic.
- One small server endpoint for the two forms, which stores each request and notifies staff.
- Hosting: the owner decides; see the data-location check in 7.7.
- Phase 0 may be plain static HTML if that is faster, as long as tokens and content files are reused later.

## 10. Work plan

Each task lists what "done" means. An agent must run these checks and report results, including failures.

**T0. Content intake.** Turn the owner's menu files into structured data.

- Done when: every dish and price from the files is in the data file; unreadable items are listed, not guessed; the owner has confirmed prices.

**T1. Tokens and style guide.** Implement section 6.

- Done when: tokens exist in one file; a style-guide page shows color, type, spacing and each component state; every text color passes the contrast rules.

**T2. Components, mobile first.**

- Done when: all section 6 components exist at 390 and 1440 px, keyboard-operable, with all states.

**T3. Page templates.** Home, Menu, Events, Gallery, Contact.

- Done when: each page renders in all three languages from the data files with no hard-coded text.

**T4. Languages.**

- Done when: switcher works, `hreflang` and `lang` are set, missing translations are listed.

**T5. Forms.**

- Done when: validation, errors and success states work; a test submission reaches the staff channel; spam control and failure fallback are tested.

**T6. SEO and structured data.**

- Done when: JSON-LD validates; sitemap exists; titles and descriptions exist in each language.

**T7. Performance and accessibility pass.**

- Done when: Core Web Vitals thresholds are met on the throttled test; keyboard and screen-reader spot checks pass; findings are written up.

**T8. Owner review and handoff.**

- Done when: the owner has reviewed a live link on their own phone; their notes are logged; a short guide explains how to update the menu, hours and phones.

## 11. Definition of done

### Prototype is done when

- Home, Menu, Events and Contact exist and work at 390 px and 1440 px.
- The menu comes from the owner's files, loaded from structured data, in at least Russian and English.
- Both forms validate and show success and error states (no backend needed yet).
- Tokens file and style-guide page exist; no text is below 12px or below the contrast rules.
- Every generated image is on a written list of placeholders.
- The owner can open it on a phone through a shareable link.

### Launch is done when

- All Prototype items are met, in Russian, Uzbek and English, with native-speaker review of Russian and Uzbek.
- No generated images are used; real photos or no photo.
- Every fact (hours, phones, address, capacity, prices, name) is confirmed by the owner and matches the Yandex and Google listings.
- Both forms reach staff in a live test; staff know how to respond.
- Core Web Vitals thresholds are met on the throttled mobile test; accessibility checks in section 8 are done.
- Privacy policy is published and the data-location question in 7.7 is answered.
- Analytics events are firing and checked; Yandex Webmaster and Google Search Console are set up.
- The owner can edit the menu, hours and phones, or knows exactly who does it.
- A short list of known issues exists and the owner has accepted it.

## 12. What we need from the owner

- Menu files (zip is ready); a confirmation of every price; the bar, cocktail, lemonade and beer menus.
- Opening hours, last seating time, and holiday closures.
- Both phone numbers confirmed; which one is for reservations and which for events.
- Capacity of each hall and the real number of seats.
- Event packages, minimum guests, deposit policy, and what is included.
- Original photos and videos (not the compressed Telegram copies), or a photo shoot date.
- Logo files in vector format (SVG) and any brand guidelines.
- Official restaurant name and legal details for the footer.
- Links to the Yandex Maps and Google Business listings, and any Yandex Eats or Uzum Tezkor listing.
- Who receives reservation and event requests, and how fast they promise to reply.
- Privacy policy text, or approval for us to draft one for legal review.

Placeholder format for anything missing: `[[OWNER: opening hours]]`. Agents must list every placeholder in their report.

## 13. Open decisions

1. Is everyday dining or events the main revenue goal? This sets the homepage order.
2. Default language: Russian (assumed) or Uzbek.
3. How requests reach staff: Telegram chat, email, or both.
4. Own ordering in Phase 1 or later, and the relationship with delivery apps.
5. Hosting location, depending on the data-location check.
6. Final visual direction, after real photography.
7. Who maintains the menu after launch.

## 14. Risks and assumptions

- **Generated images**: the concept's mood may not match the real rooms. Do not ship them.
- **Unverified facts**: hours, rating, average bill and seat count came from a map listing via the concept and conflict with Telegram in places.
- **Aggregator dominance**: guests may prefer to order and book inside Yandex or Uzum. The site must still win on events, menu clarity and direct contact.
- **Language quality**: poor Uzbek or Russian copy damages trust. Budget for review.
- **Fonts**: the concept's Latin-only fonts would break Russian text.
- **Thin social proof**: the Telegram channel is small, so the site cannot lean on followers or press.
- **Content upkeep**: if updating the menu is hard, the site will go stale.

## 15. Rules for AI agents

Paste this preamble at the start of every agent prompt, then add the specific task from section 10.

```
You are building the website for Fenix Restobar, a restaurant in Tashkent, Uzbekistan. Read the Fenix Website Build Brief first and follow it.

Rules:
1. Never invent facts: prices, hours, dishes, awards, capacity, addresses or phone numbers. Use only the brief and the owner's materials. If something is missing, insert a visible placeholder like [[OWNER: opening hours]] and list it in your report.
2. Design mobile first (390 px wide), then desktop.
3. Use only the design tokens in the brief. If you need a new color, size or font, say why.
4. Text must meet WCAG 2.2 AA. Keep all visible text in the language files (ru, uz, en), never hard-coded.
5. Follow the performance budgets in section 8.
6. Treat every image in the prototype as a placeholder and mark it.
7. Before saying a task is done, run its "Done when" checks and report the results, including anything that failed.
8. If the brief conflicts with the request, stop and ask.
```

Suggested prompt order: T0 (content), then T1 (tokens and style guide), T2 (components), T3 and T4 (pages and languages), T5 (forms), T6 and T7 (SEO, performance, accessibility), T8 (review).

## 16. Sources used

- Fenix Telegram channel: t.me/fenix\_tashkent and t.me/s/fenix\_tashkent (address, halls, events, phones).
- Yandex Uzbekistan restaurant guide, May 2026: openkitchen.eda.yandex (booking with Yandex ID, price bands).
- Kun.uz reports on Wolt's exit (5 March 2026) and on dominant delivery platforms.
- sayt.uz, atmos.uz and cartdna.com on payment methods in Uzbekistan.
- Magier, "The Best Restaurant Website Designs" (2026): practices from Noma, Dishoom, Padella and others; Core Web Vitals thresholds.
- The three design concepts supplied by the project owner (files: data.js, styles.css, fonts.css, screenshots).

Instagram could not be read by our tools, so nothing here comes from it.
