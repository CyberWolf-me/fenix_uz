/* ═══════════ app shell: nav, topbar, cmdk ═══════════ */
const NAV = [
  { group: 'grp_ops', items: [
    { id: 'dispatch', icon: 'dpad', k: 'dispatch', badge: 'live' },
    { id: 'bookings', icon: 'calendar', k: 'bookings', badge: 4 },
    { id: 'banquets', icon: 'star', k: 'banquets' },
  ]},
  { group: 'grp_venue', items: [
    { id: 'floor', icon: 'grid', k: 'floor' },
    { id: 'couriers', icon: 'bike', k: 'couriers', badge: 3 },
  ]},
  { group: 'grp_admin', items: [
    { id: 'menu', icon: 'menuBook', k: 'menu' },
    { id: 'staff', icon: 'users', k: 'staff' },
    { id: 'analytics', icon: 'chart', k: 'analytics' },
    { id: 'settings', icon: 'gear', k: 'settings' },
  ]},
];

const PAGE_META = {
  dispatch: { eyebrow: 'FENIX · OPS', icon: 'dpad' },
  bookings: { eyebrow: 'FENIX · OPS', icon: 'calendar' },
  banquets: { eyebrow: 'FENIX · OPS', icon: 'star' },
  floor: { eyebrow: 'FENIX · VENUE', icon: 'grid' },
  couriers: { eyebrow: 'FENIX · VENUE', icon: 'bike' },
  menu: { eyebrow: 'FENIX · ADMIN', icon: 'menuBook' },
  staff: { eyebrow: 'FENIX · ADMIN', icon: 'users' },
  analytics: { eyebrow: 'FENIX · ADMIN', icon: 'chart' },
  settings: { eyebrow: 'FENIX · ADMIN', icon: 'gear' },
};

function Sidebar({ page, setPage, rail, t, counts }) {
  return (
    <nav className="nav" aria-label="Main">
      <div className="nav-brand">
        <div className="brand-mark"><Icon name="layers" size={17} stroke={1.7} /></div>
        <div className="brand-txt">
          <div className="brand-name">Fenix</div>
          <div className="brand-sub">Terminal &amp; Dispatch OS</div>
        </div>
      </div>
      <div className="nav-scroll">
        {NAV.map((g) => (
          <div className="nav-group" key={g.group}>
            <div className="nav-group-label">{t(g.group)}</div>
            {g.items.map((it) => {
              const on = page === it.id;
              const b = it.badge === 'live' ? counts.live : it.badge;
              return (
                <button key={it.id} className="nav-item" data-on={on ? '1' : '0'}
                        onClick={() => setPage(it.id)} title={rail ? t(it.k) : undefined}>
                  <Icon name={it.icon} size={16} />
                  <span className="nav-item-txt">{t(it.k)}</span>
                  {b != null && (
                    <span className="nav-badge" data-tone={it.badge === 'live' ? 'accent' : 'muted'}>{b}</span>
                  )}
                  {rail && b != null && <span className="nav-dot" />}
                </button>
              );
            })}
          </div>
        ))}
      </div>
      <div className="nav-foot">
        <button className="nav-user">
          <span className="avatar" data-tone="accent">АШ</span>
          <span className="nav-user-txt">
            <span className="nav-user-name">Алмасов Ш.</span>
            <span className="nav-user-role">Диспетчер · Смена 1</span>
          </span>
        </button>
      </div>
    </nav>
  );
}

function Topbar({ page, t, rail, setRail, now, onSearch, theme, setTheme, lang, setLang, onNew, toast }) {
  const hh = new Date(now);
  const clock = [hh.getHours(), hh.getMinutes(), hh.getSeconds()]
    .map((x) => String(x).padStart(2, '0')).join(':');
  const meta = PAGE_META[page] || {};
  return (
    <header className="topbar">
      <button className="btn btn-ghost btn-icon" onClick={() => setRail(!rail)} title="Панель">
        <Icon name="panel" size={16} />
      </button>
      <div className="topbar-page">
        <div className="topbar-eyebrow">{meta.eyebrow}</div>
        <h1 className="topbar-title" data-screen-label={t(page)}>{t(page)}</h1>
      </div>

      <div className="topbar-mid">
        <span className="live"><i />{t('live')}</span>
        <span className="clock"><Icon name="clock" size={13} />{t('shift')}: <b>{clock}</b></span>
      </div>

      <div className="topbar-right">
        <button className="btn btn-ghost btn-sm" onClick={onSearch} title={t('search_short')} style={{ gap: 6 }}>
          <Icon name="search" size={14} />
          <span className="kbd">⌘K</span>
        </button>

        <div className="seg" role="group" aria-label={t('theme')}>
          {THEMES.map((th) => (
            <button key={th.id} data-on={theme === th.id ? '1' : '0'} onClick={() => setTheme(th.id)}
                    title={th.label} style={{ padding: '0 7px' }}>
              <span style={{
                width: 9, height: 9, borderRadius: 2, display: 'block',
                background: th.swatch, boxShadow: '0 0 0 1px var(--line)',
              }} />
            </button>
          ))}
        </div>

        <button className="btn btn-ghost btn-sm" onClick={() => setLang(lang === 'ru' ? 'uz' : lang === 'uz' ? 'uzc' : 'ru')}
                title={t('language')}
                style={{ fontFamily: 'var(--f-mono)', fontSize: 10, letterSpacing: '.04em', padding: '0 6px' }}>
          {lang === 'ru' ? 'RU' : lang === 'uz' ? 'UZ' : 'ЎЗ'}
        </button>

        <button className="btn btn-ghost btn-icon btn-sm" title={t('attention')} onClick={() => toast('6 заказов требуют подтверждения', 'warn', 'alert')}>
          <Icon name="bell" size={15} />
        </button>
        <Btn size="sm" variant="accent" icon="plus" onClick={onNew}>{t('create')}</Btn>
      </div>
    </header>
  );
}

function CommandPalette({ t, onClose, go }) {
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);
  const inputRef = useRef(null);
  useEffect(() => { inputRef.current && inputRef.current.focus(); }, []);

  const cmds = [
    ...NAV.flatMap((g) => g.items.map((i) => ({ group: t(g.group), label: t(i.k), icon: i.icon, run: () => go(i.id) }))),
    { group: 'Действия', label: 'Принять все новые заказы', icon: 'check', run: () => { go('dispatch'); onClose(); } },
    { group: 'Действия', label: 'Найти заказ #WEB-3307', icon: 'search', run: () => go('dispatch') },
    { group: 'Действия', label: 'Распечатать фискальный чек', icon: 'printer', run: () => go('dispatch') },
  ];
  const filtered = cmds.filter((c) => c.label.toLowerCase().includes(q.toLowerCase()));
  const groups = [...new Set(filtered.map((c) => c.group))];

  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((i) => Math.min(filtered.length - 1, i + 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)); }
    if (e.key === 'Enter' && filtered[idx]) { filtered[idx].run(); onClose(); }
  };

  return (
    <Modal onClose={onClose} width={520} className="cmdk-scrim modal cmdk" label="Командная палитра">
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '13px 15px', borderBottom: '1px solid var(--line)' }}>
        <Icon name="search" size={15} />
        <input autoFocus value={q} onChange={(e) => { setQ(e.target.value); setIdx(0); }} onKeyDown={onKey}
               placeholder={t('cmdk_ph')}
               style={{ flex: 1, background: 'none', border: 0, outline: 'none', fontSize: 13.5 }} />
        <span className="kbd">Esc</span>
      </div>
      <div className="modal-body" style={{ padding: 9, maxHeight: 330 }}>
        {groups.map((g) => (
          <div key={g}>
            <div className="cmdk-group">{g}</div>
            {filtered.filter((c) => c.group === g).map((c) => {
              const gi = filtered.indexOf(c);
              return (
                <div key={c.label} className="cmdk-row" data-on={gi === idx ? '1' : '0'}
                     onMouseEnter={() => setIdx(gi)}
                     onClick={() => { c.run(); onClose(); }}>
                  <Icon name={c.icon} size={14} />
                  <span>{c.label}</span>
                  {gi === idx && <span className="cmdk-row-hint">↵</span>}
                </div>
              );
            })}
          </div>
        ))}
        {!filtered.length && <div className="empty">Ничего не найдено</div>}
      </div>
      <div className="modal-foot" style={{ fontSize: 10, color: 'var(--text-3)' }}>
        <span className="kbd">↑↓</span> навигация <span className="kbd">↵</span> {t('cmdk_hint')}
      </div>
    </Modal>
  );
}

const THEMES = [
  { id: 'gold', label: 'Тёмное золото', swatch: '#d3aa63' },
  { id: 'graphite', label: 'Графит', swatch: '#78a6dc' },
  { id: 'oxblood', label: 'Оксблад', swatch: '#dd9a72' },
  { id: 'cream', label: 'Крем (день)', swatch: '#9a6f1e' },
];
const DIRECTIONS = [
  { id: 'a', label: 'Смола · luxury', note: 'Серифные цифры, тонкие рамки, много воздуха' },
  { id: 'b', label: 'Медь · hospitality', note: 'Крупный гротеск, скругления, мягкие карточки' },
  { id: 'c', label: 'Консоль · ops', note: 'Моно, жёсткие углы, максимум плотности' },
];

Object.assign(window, { NAV, PAGE_META, Sidebar, Topbar, CommandPalette, THEMES, DIRECTIONS });
