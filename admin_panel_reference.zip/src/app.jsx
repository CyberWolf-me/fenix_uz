/* ═══════════ root ═══════════ */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "gold",
  "dir": "a",
  "density": "balanced",
  "lang": "ru",
  "rail": false,
  "sound": true,
  "accentOverride": ""
}/*EDITMODE-END*/;

const ACCENTS = {
  gold: [['', 'Золото'], ['#b98d4a', 'Медь'], ['#9aa87a', 'Шалфей'], ['#c98b7a', 'Терракота'], ['#8fa4cd', 'Сталь']],
  graphite: [['', 'Сталь'], ['#6fb3a8', 'Тил'], ['#b6a3d8', 'Лаванда'], ['#d3a04b', 'Янтарь'], ['#d97f8e', 'Роза']],
  oxblood: [['', 'Медь'], ['#d9b06a', 'Латунь'], ['#a8b88d', 'Олива'], ['#c98fa8', 'Пыльная роза'], ['#8fa0c4', 'Слейт']],
  cream: [['', 'Охра'], ['#8a5a2b', 'Сепия'], ['#4a6b52', 'Мох'], ['#3a5f96', 'Индиго'], ['#8c4a52', 'Бордо']],
};

function App() {
  const [tw, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const theme = tw.theme, dir = tw.dir, lang = tw.lang;

  const [page, setPage] = useState(() => {
    try { return localStorage.getItem('fx.page') || 'dispatch'; } catch (e) { return 'dispatch'; }
  });
  const [view, setView] = useState(() => {
    try { return localStorage.getItem('fx.view') || 'board'; } catch (e) { return 'board'; }
  });
  const [orders, setOrders] = useState(FX.orders);
  const [openOrder, setOpenOrder] = useState(null);
  const [printOrder, setPrintOrder] = useState(null);
  const [cmdk, setCmdk] = useState(false);
  const [toasts, pushToast] = useToasts();
  const now = useTick(1000);

  const t = useCallback((k) => (FX_I18N[lang] && FX_I18N[lang][k]) || (FX_I18N.ru[k] || k), [lang]);

  /* persist */
  useEffect(() => { try { localStorage.setItem('fx.page', page); } catch (e) {} }, [page]);
  useEffect(() => { try { localStorage.setItem('fx.view', view); } catch (e) {} }, [view]);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.dir = dir;
    document.documentElement.dataset.density = tw.density;
    document.documentElement.lang = lang === 'ru' ? 'ru' : 'uz';
  }, [theme, dir, tw.density, lang]);

  /* accent override */
  useEffect(() => {
    const root = document.documentElement;
    if (tw.accentOverride) {
      root.style.setProperty('--accent', tw.accentOverride);
      root.style.setProperty('--accent-soft', tw.accentOverride + '22');
      root.style.setProperty('--accent-glow', tw.accentOverride + '38');
    } else {
      root.style.removeProperty('--accent');
      root.style.removeProperty('--accent-soft');
      root.style.removeProperty('--accent-glow');
    }
  }, [tw.accentOverride]);

  /* live SLA escalation */
  const latePrev = useRef(0);
  useEffect(() => {
    const late = orders.filter((o) => o.col !== 'done' && slaState(o).late).length;
    if (late > latePrev.current && tw.sound) beep(late > latePrev.current + 1 ? 'danger' : 'alert');
    latePrev.current = late;
  }, [orders, tw.sound]);

  /* keyboard */
  useEffect(() => {
    const onKey = (e) => {
      const tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || e.target.isContentEditable) return;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setCmdk((v) => !v); return; }
      if (e.key === 'Escape') { setCmdk(false); setOpenOrder(null); setPrintOrder(null); }
      if (['1', '2', '3', '4'].includes(e.key) && page === 'dispatch') {
        const col = ['new', 'kitchen', 'way', 'done'][Number(e.key) - 1];
        pushToast(t(COLUMNS.find((c) => c.id === col).label) + ' · фильтр', 'ok', 'grid');
      }
      if (e.key === 'g') setPage('dispatch');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [page, t, pushToast]);

  const advance = useCallback((o) => {
    const next = { new: 'kitchen', kitchen: 'way', way: 'done', done: 'done' }[o.col];
    setOrders((list) => list.map((x) => x.id === o.id ? { ...x, col: next, elapsed: next === 'done' ? x.elapsed : x.elapsed } : x));
    pushToast(`#${o.id} → ${t(COLUMNS.find((c) => c.id === next).label)}`, 'ok', next === 'done' ? 'check' : 'arrowRight');
    if (openOrder && openOrder.id === o.id) setOpenOrder({ ...openOrder, col: next });
  }, [t, pushToast, openOrder]);

  const dispatch = useCallback((action, o) => {
    if (action === 'acceptAll') {
      setOrders((list) => list.map((x) => x.col === 'new' ? { ...x, col: 'kitchen' } : x));
      pushToast('Все новые заказы приняты', 'ok', 'check');
    } else if (action === 'advance') advance(o);
    else if (action === 'print') setPrintOrder(o);
  }, [advance, pushToast]);

  const counts = { live: orders.filter((o) => o.col !== 'done').length };
  const loaded = openOrder ? orders.find((o) => o.id === openOrder.id) || openOrder : null;

  const screens = {
    dispatch: <Dispatch t={t} orders={orders} dispatch={dispatch} view={view} setView={setView}
                        onOpen={setOpenOrder} onAdvance={(o) => advance(o)}
                        onPrint={setPrintOrder} toast={pushToast} lang={lang} />,
    bookings: <Bookings t={t} toast={pushToast} />,
    banquets: <Banquets t={t} toast={pushToast} />,
    floor: <Floor t={t} toast={pushToast} />,
    couriers: <Couriers t={t} toast={pushToast} />,
    menu: <MenuScreen t={t} toast={pushToast} />,
    staff: <Staff t={t} toast={pushToast} />,
    analytics: <Analytics t={t} />,
    settings: <Settings t={t} theme={theme} setTheme={(v) => setTweak('theme', v)} dir={dir} setDir={(v) => setTweak('dir', v)}
                       lang={lang} setLang={(v) => setTweak('lang', v)} sound={tw.sound} setSound={(v) => setTweak('sound', v)}
                       rail={tw.rail} setRail={(v) => setTweak('rail', v)} />,
  };

  return (
    <div className="app" data-rail={tw.rail ? '1' : '0'}>
      <Sidebar page={page} setPage={setPage} rail={tw.rail} t={t} counts={counts} />
      <div className="main">
        <Topbar page={page} t={t} rail={tw.rail} setRail={(v) => setTweak('rail', v)} now={now}
                onSearch={() => setCmdk(true)} theme={theme} setTheme={(v) => setTweak('theme', v)}
                lang={lang} setLang={(v) => setTweak('lang', v)} onNew={() => pushToast('Новая заявка', 'ok', 'plus')}
                toast={pushToast} />
        <main style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
          {screens[page]}
        </main>
      </div>

      {loaded && (
        <OrderDrawer o={loaded} t={t} onClose={() => setOpenOrder(null)}
                     onAdvance={(o) => advance(o)} onPrint={(o) => { setPrintOrder(o); }}
                     onToast={(m) => pushToast(m, 'ok', 'phone')} />
      )}
      {printOrder && <ReceiptModal o={printOrder} t={t} onClose={() => setPrintOrder(null)} />}
      {cmdk && <CommandPalette t={t} onClose={() => setCmdk(false)} go={(p) => { setPage(p); setCmdk(false); }} />}
      <Toasts items={toasts} />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Тема">
          <TweakSelect label="Тема оформления" value={theme} onChange={(v) => setTweak('theme', v)}
            options={THEMES.map((x) => ({ value: x.id, label: x.label }))} />
          <TweakColor label="Акцент" value={tw.accentOverride}
            options={(ACCENTS[theme] || ACCENTS.gold).map((a) => a[0] || THEME_FALLBACK[theme])}
            onChange={(v) => setTweak('accentOverride', v === THEME_FALLBACK[theme] ? '' : v)} />
        </TweakSection>
        <TweakSection label="Форма">
          <TweakRadio label="Направление" value={dir} onChange={(v) => setTweak('dir', v)}
            options={[['a', 'Luxury'], ['b', 'Медь'], ['c', 'Консоль']]} />
          <TweakRadio label="Плотность" value={tw.density} onChange={(v) => setTweak('density', v)}
            options={[['compact', 'Плотно'], ['balanced', 'Баланс'], ['airy', 'Воздух']]} />
          <TweakToggle label="Свёрнутая панель" value={tw.rail} onChange={(v) => setTweak('rail', v)} />
        </TweakSection>
        <TweakSection label="Операции">
          <TweakRadio label="Язык" value={lang} onChange={(v) => setTweak('lang', v)}
            options={[['ru', 'RU'], ['uz', 'UZ'], ['uzc', 'ЎЗ']]} />
          <TweakToggle label="Звук при просрочке" value={tw.sound} onChange={(v) => setTweak('sound', v)} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const THEME_FALLBACK = { gold: '#d3aa63', graphite: '#78a6dc', oxblood: '#dd9a72', cream: '#9a6f1e' };

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
